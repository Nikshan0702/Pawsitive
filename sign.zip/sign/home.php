<?php include 'header.php'; ?>
<br><br><br>









<div class="slideshow-container">
    <div class="mySlides fade">
      <img src="grooming.webp" style="width:100%">
      <div class="text">Best Grooming facilities</div>
    </div>
    
    <div class="mySlides fade">
      <img src="takecare.webp" style="width:100%">
      <div class="text">We take care of your lovely pet</div>
    </div>
    
    <div class="mySlides fade">
      <img src="accredited.png" style="width:100%">
      <div class="text">Accredited Staff</div>
    </div>

    <div class="mySlides fade">
        <img src="petsupplies.jpeg" style="width:100%">
        <div class="text">Variety of pet supplies</div>
      </div>
    
    </div>
    <br>
    
    <div style="text-align:center">
      <span class="dot"></span> 
      <span class="dot"></span> 
      <span class="dot"></span> 
      <span class="dot"></span> 
    </div>

<div class="welcome">
<h1><center>WELCOME TO PAWSITIVE PETCARE</center></h1>
</div>
<br>
<p><center><font style="font-size: 50px;">We Offer The Best Online Pet Services</font></center></p>
  </div>
  <br>


  <div class="container">
  <div class="video-container">
    <iframe width="560" height="315" src="https://www.youtube.com/embed/Tn3lZE0rRBs?si=iB6op8GfX3TTUgta" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen style="margin-bottom: 80px;"></iframe>
  </div>
  <div class="paragraph-container">
    <p style="font-size: 35px; "> 
        <br> <br> <br>
   Get started with pet care 101!
</p>
  </div>
</div>





<?php include 'newfooter.php' ?>